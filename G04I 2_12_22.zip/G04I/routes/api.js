const express = require ('express')
const router = express.Router()

router.get('/peliculas', (req,res)=>{
    res.send('Listado de Peliculas')
})

router.get('/series', (req,res)=>{
    res.send('Listado de series')
})

module.exports = router