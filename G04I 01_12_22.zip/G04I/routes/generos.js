const express = require ('express')
const router = express.Router()
const generosCtrl = require('../controllers/generosCtrl')

router.get('/', generosCtrl.generoListar)

//Guardar
router.post('/', generosCtrl.generoGuarda)

//actualizar
router.put('/', generosCtrl.generoActualizar)

//eliminar
router.delete('/:id', generosCtrl.generoEliminar)

module.exports = router