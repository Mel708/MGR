const http = require('http')
const puerto = 3000

const fs = require('fs')// fileSystem

function getText(url){
    return new Promise(function(resolve, reject){
        readFile(url, 'utf-8', (err,data)=>{
            if(err){
                reject(err)
            }
            resolve(data)
        })
    })
}

http.createServer((req,res)=>{
    console.log(req.url)
    if(req.url == "/registro"){
        //res.write("pagina registro")
        //const arch = fs.readFileSync('registro.html', 'utf-8')
        getText('registro.html')
        .then((result)=>{
            console.log(result)
            //es.write(arch)
            res.write(result)
            return res.end()})
        .catch((error) =>{console.log(error)})
        
    }

    res.write("404")
    res.end()
}).listen(puerto)
console.log("servidor corriendo: " + puerto)