const usuarioModel = require ('../models/usuarioSchema')
const bcryptjs = require ('bcryptjs')

const usuarioGuarda = async (req,res) =>{
    console.log(req.body)
    
    try {
        const usuario = new usuarioModel(req.body)
        usuario.contrasena = await bcryptjs.hash(usuario.contrasena,10)
        await usuario.save()
        res.status(200).json({msj : "Usuario Creado"})
                
    } catch (err) {
        res.status(400).json({msj : "error en usuarioGuarda: " + err})
        
    }
}

const usuarioLogin = async (req,res) =>{
    console.log("intento de login")
    console.log(req.body)
    

    const {correo, contrasena} = req.body
    try {
        errores = false
        if(correo == ""){errores = true
            res.status(400).json({'msj':"Correo Incorrecto"})
        }
        if(contrasena == ""){errores = true
            res.status(400).json({'msj':"Contraseña Incorrecta"})
        }

        
        if(!errores){
            //validar
            //usar find en vez de findOne
            let usuario = await usuarioModel.find({ 'correo' : correo, 'contrasena' : contrasena })
            
            //res.send("accesando ...")
            if(!usuario){
                console.log("no encontrado")
                res.status(400).json({msj : "no"})
            }else{
                console.log("usuario: " + usuario.nombre)
                res.status(200).json({ msj : "ok"})            }
            
        }
    } catch (err) { console.log("error usuarioLogin "+ err) }
}

module.exports={
    usuarioLogin,
    usuarioGuarda
}