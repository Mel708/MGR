const c = require('colors')

console.log("Hola Mundo!".blue)
console.log("MisionTic 2022".bgRed)
console.log("G04".yellow)