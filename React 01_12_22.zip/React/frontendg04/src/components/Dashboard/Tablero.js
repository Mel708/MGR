import { useEffect } from "react"
import { useNavigate } from "react-router-dom"

export function Tablero(){
    //
    const navigate = useNavigate()
    useEffect(()=>{
        try {
            const token = localStorage.getItem("token")
                            
                if(!token)
                    navigate("/")
                else
                console.log ("token: " + token)

        } catch (error) {
            console.log("Error de Seguridad")
            navigate("/")
        }

    },[])

    function handleCerrar(){
        localStorage.removeItem("token")
        navigate("/login")
    }

    return <><h1>Panel de Administración</h1>
        <div className="nav-item dropdown my-2 mysm-0">
        <button onClick={handleCerrar} type="button" class="btn-close" aria-label="Close">Cerrar</button>
        </div>
    </>
        
    
}