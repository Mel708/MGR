import { useParams } from "react-router-dom"

export function PeliculasEdit(){
    const {id} = useParams()
    console.log(id)
    return<>Editando Pelicula</>
}