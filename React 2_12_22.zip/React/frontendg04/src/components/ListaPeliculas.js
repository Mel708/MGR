import { useState, useEffect } from "react"
import { Pelicula } from "./Pelicula"

export function ListaPeliculas(){
    
    const [items,setItems] = useState([])
    console.log("algo")
    function cargar (){
        fetch("http://localhost:3000/api/items") 
        .then (response => response.json())
        .then(data => {console.log(data)
                setItems(data)
            })
        .catch(err => console.log("el error es: " + err))
    }

    useEffect(()=>{ cargar() } , [])
    

    return <>
        <div className='row my-2'>
                <div className='container'>
                    <div className='row align- center'>
                        <div className='col m-5'>
                            <div className="row">
                                { items.map(dato =>(
                                    //<div className="col-20">
                                        <Pelicula titulo={ dato.titulo }
                                        imagen = { dato.imagen }
                                        duracion={ dato.duracion }
                                        tipo = { dato.tipo }
                                        ano = { dato.ano }
                                        genero = { dato.genero }
                                        
                                        />
                                    
                                    
                                    //</div>
                                    )) 
                                } 
                            </div>                                                    
                        </div>
                    </div>
                </div>            
            </div>      
    </>
}
