import React from 'react'
import ReactDOM from 'react-dom/client'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import './css/bootstrap.min.css'


import { Menu } from './components/Header'
import { Login } from './components/Login'
import { ListaPeliculas } from './components/ListaPeliculas'
import { Tablero } from './components/Dashboard/Tablero'




const root = ReactDOM.createRoot(document.getElementById('root'))
root.render( <>

    <Router>
        <Menu/>
        <div className='container'>
            <div className='row my-5'>
                <Routes>                               
                    <Route path="/" element={<ListaPeliculas/>}></Route>
                    <Route path="/login" element={<Login/>}></Route>
                    <Route path="/tablero" element={<Tablero/>}></Route>
                </Routes>                
            </div>
        </div>
    </Router>                
    </>    
    )