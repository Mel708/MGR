import { useEffect } from "react"
import { useNavigate } from "react-router-dom"
import { Routes, Route, Link } from "react-router-dom"

import { GenerosList } from "../Generos/GenerosList"

export function Tablero(){
    //
    const navigate = useNavigate()
    useEffect(()=>{
        try {
            const token = localStorage.getItem("token")
                            
                if(!token)
                    navigate("/")
                else
                console.log ("token: " + token)

        } catch (error) {
            console.log("Error de Seguridad")
            navigate("/")
        }

    },[])

    function handleCerrar(){
        localStorage.removeItem("token")
        navigate("/login")
    }

    return <><h1>Panel de Administración</h1>
        <div className="row">
            <div className="col-3">
                Opciones
                <ul>
                    <li><Link to="/tablero/generosList">Generos</Link></li>
                </ul>
            </div>
            <div className="col-9">
                <Routes>
                    <Route path="/generosList" element={GenerosList}></Route>
                </Routes>
            </div>
        </div>
        
        
        {/*<div className="nav-item dropdown my-2 mysm-0">
        <button onClick={handleCerrar} type="button" aria-label="Close">Cerrar</button>
        </div>*/}
    </>
        
    
}