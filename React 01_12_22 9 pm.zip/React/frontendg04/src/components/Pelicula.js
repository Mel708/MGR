
export function Pelicula(props){
        
    return <>
        <div className="col-3">
            <div className="card" >
                <img src={ props.imagen } className="card-img-top" alt="..."/>
                <div className="card-body">
                    <h2 className="card-title">{ props.titulo}</h2>                
                </div>
            <ul className="list-group list-group-flush">
                <li className="list-group-item">{ props.tipo }</li>
                <li className="list-group-item">Año: { props.ano }</li>
                <li className="list-group-item">Duracion: { props.duracion } minutos</li>
                <li className="list-group-item">Genero: { props.genero}</li>
                <li className="list-group-item">Actores: { props.actores }</li>
            </ul>
            <div className="card-body">
                <a href="#" className="card-link">Ver</a>                
            </div>
            </div>

        </div>
    </>
}