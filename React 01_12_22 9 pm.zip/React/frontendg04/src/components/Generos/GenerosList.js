import { useEffect, useState } from "react";

export function GenerosList(){
    const [generos, setGeneros] = useState([])

    function cargar(){
        fetch("http://localhost:3000/api/generos")
        .then(response => response.json())
        .data(data => setGeneros(data))
    }

    useEffect(() => {
        cargar
        ()
    }, [])
    return<>
        <div className="container my-5">
            <div className="row">
                <table className="table">
                    { 
                        generos.map(dato =>(
                            <tr>
                                <td>{dato.nombre}</td>
                            </tr>
                        ))
                    }
                </table>
            </div>
        </div>
    </>
}